# AI Stock Analysis (ภาษาไทย)

โปรเจกต์ React เว็บ AI วิเคราะห์หุ้นต่างประเทศ โดยใช้ข้อมูลหุ้นยอดนิยม และวิเคราะห์ด้วย AI

## วิธีใช้งาน

1. ติดตั้ง dependencies:
```
npm install
```

2. รันเว็บในเครื่อง:
```
npm start
```

3. สร้างไฟล์ build:
```
npm run build
```